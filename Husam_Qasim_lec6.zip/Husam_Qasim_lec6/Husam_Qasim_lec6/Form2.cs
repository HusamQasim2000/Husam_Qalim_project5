﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Husam_Qasim_lec6
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            pictureBox1.Width = pictureBox1.Height = 300;
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.BackColor = Color.Red;
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Image = Image.FromFile(@"F:\WEB_DESIGN\lesson_3\img1/picture.jfif");
            pictureBox1.BackgroundImage = Image.FromFile(@"F:\WEB_DESIGN\lesson_4\img2/picture3.jfif");
            toolTip1.SetToolTip(pictureBox1, "picturebox الاداة");
            this.AutoSize = true;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = null;
        }
    }
}
